const { Sequelize } = require("sequelize");

const isLocal = process.env.NODE_ENV === "local";

const sequelize = new Sequelize({
  dialect: "postgres",
  host: isLocal
    ? "localhost"
    : "foodcost-db.cr4acawsy1bf.ap-southeast-2.rds.amazonaws.com",
  port: 5432,
  username: "foodcostadmin", // Same for local and remote
  password: "562GodIsMy", // Same for local and remote
  database: "foodcost", // Same for local and remote
  dialectOptions: isLocal
    ? {}
    : {
        ssl: {
          require: true,
          rejectUnauthorized: false, // For testing; use CA certificate in production
        },
      },
  logging: false, // Disable SQL query logging; set to console.log for debugging
});

// Define models (equivalent to TypeORM entities)
const Invoice = sequelize.define(
  "Invoice",
  {
    id: {
      type: Sequelize.DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    fileName: {
      type: Sequelize.DataTypes.STRING,
      allowNull: false,
    },
    totalAmount: {
      type: Sequelize.DataTypes.FLOAT,
      allowNull: false,
    },
  },
  { tableName: "Invoice", timestamps: false }
);

const Ingredient = sequelize.define(
  "Ingredient",
  {
    id: {
      type: Sequelize.DataTypes.STRING,
      primaryKey: true,
    },
    unitPrice: {
      type: Sequelize.DataTypes.FLOAT,
      allowNull: false,
    },
  },
  { tableName: "Ingredient", timestamps: false }
);

const Recipe = sequelize.define(
  "Recipe",
  {
    id: {
      type: Sequelize.DataTypes.STRING,
      primaryKey: true,
    },
    name: {
      type: Sequelize.DataTypes.STRING,
      allowNull: false,
    },
    totalCost: {
      type: Sequelize.DataTypes.FLOAT,
      allowNull: false,
      defaultValue: 0,
    },
  },
  { tableName: "Recipe", timestamps: false }
);

const Sale = sequelize.define(
  "Sale",
  {
    id: {
      type: Sequelize.DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    saleAmount: {
      type: Sequelize.DataTypes.FLOAT,
      allowNull: false,
    },
  },
  { tableName: "Sale", timestamps: false }
);

const RecipeIngredient = sequelize.define(
  "RecipeIngredient",
  {
    id: {
      type: Sequelize.DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    quantity: {
      type: Sequelize.DataTypes.FLOAT,
      allowNull: false,
    },
  },
  { tableName: "RecipeIngredient", timestamps: false }
);

// Define relationships
Recipe.belongsToMany(Ingredient, {
  through: RecipeIngredient,
  foreignKey: "recipeId",
});
Ingredient.belongsToMany(Recipe, {
  through: RecipeIngredient,
  foreignKey: "ingredientId",
});
RecipeIngredient.belongsTo(Recipe, { foreignKey: "recipeId" });
RecipeIngredient.belongsTo(Ingredient, { foreignKey: "ingredientId" });

Sale.belongsTo(Recipe, { foreignKey: "recipeId" });
Recipe.hasMany(Sale, { foreignKey: "recipeId" });

module.exports = {
  sequelize,
  Invoice,
  Ingredient,
  Recipe,
  RecipeIngredient,
  Sale,
};
