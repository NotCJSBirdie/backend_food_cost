const {
  Invoice,
  Ingredient,
  Recipe,
  RecipeIngredient,
  Sale,
} = require("./data-source");
console.log("Loading resolvers.js - Models:", {
  Invoice,
  Ingredient,
  Recipe,
  RecipeIngredient,
  Sale,
});

const resolvers = {
  Query: {
    invoices: async () => {
      return await Invoice.findAll();
    },
    recipes: async () => {
      return await Recipe.findAll({
        include: [
          {
            model: RecipeIngredient,
            as: "ingredients",
            include: [{ model: Ingredient, as: "ingredient" }],
          },
        ],
      });
    },
    sales: async () => {
      return await Sale.findAll({
        include: [{ model: Recipe, as: "recipe" }],
      });
    },
  },
  Mutation: {
    uploadInvoice: async (_, { fileName, totalAmount }) => {
      return await Invoice.create({ fileName, totalAmount });
    },
    createRecipe: async (_, { name, ingredientIds, quantities }) => {
      const recipe = await Recipe.create({ name, totalCost: 0 });
      let totalCost = 0;

      for (let i = 0; i < ingredientIds.length; i++) {
        const ingredient = await Ingredient.findByPk(ingredientIds[i]);
        if (ingredient) {
          await RecipeIngredient.create({
            recipeId: recipe.id,
            ingredientId: ingredientIds[i],
            quantity: quantities[i],
          });
          totalCost += ingredient.unitPrice * quantities[i];
        }
      }

      recipe.totalCost = totalCost;
      await recipe.save();
      return recipe;
    },
    recordSale: async (_, { recipeId, saleAmount }) => {
      const recipe = await Recipe.findByPk(recipeId);
      if (!recipe) {
        throw new Error(`Recipe with ID ${recipeId} not found`);
      }
      return await Sale.create({ saleAmount, recipeId });
    },
  },
};

console.log("Exporting resolvers:", resolvers);
module.exports = resolvers;
